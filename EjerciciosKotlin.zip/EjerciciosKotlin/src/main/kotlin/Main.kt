/*1.Hacer un programa que llene un arreglo de 10 enteros y
    debera elevar al cuadrado cada elemento del arreglo*/
/*fun main(args: Array<String>) {

    val arreglo: Array<Int> = arrayOf(1,2,3,4,5,6,7,8,9,10)
    println("numero = $arreglo[0]")

    arreglo.forEach{
        println("Valor: $it")
    }
    val square = pow (number = arreglo[0])
    println("Cuadrado0: $square")
    val square1 = pow (number = arreglo[1])
    println("Cuadrado1: $square1")
    val square2 = pow (number = arreglo[2])
    println("Cuadrado2: $square2")
    val square3 = pow (number = arreglo[3])
    println("Cuadrado3: $square3")
    val square4 = pow (number = arreglo[4])
    println("Cuadrado4: $square4")
    val square5 = pow (number = arreglo[5])
    println("Cuadrado5: $square5")
    val square6 = pow (number = arreglo[6])
    println("Cuadrado6: $square6")
    val square7 = pow (number = arreglo[7])
    println("Cuadrado7: $square7")
    val square8 = pow (number = arreglo[8])
    println("Cuadrado8: $square8")
    val square9 = pow (number = arreglo[9])
    println("Cuadrado9: $square9")
}
fun pow(number: Int, pow: Int = 2):Int {
    var result: Int = 1
    for (i in 1..pow) {
        result = result * number
    }
    return result
}
 */

/* 2.Hacer un programa que pida un número entre 1 y 9999 y
   nos diga cuantas unidades de millar, centenas, decenas y unidades tiene*/
/*fun main(args: Array<String>) {
    var num: Int

    print("Digita un numero entre 1 y 9999:")
    num = readLine()?.toInt() as Int

    if(num >=1 && num <= 9999){
        var mill:Int = num/1000
        var cen:Int = num/100
        var dec:Int = num/10
        var uni: Int = num/1



        println("Cantidad de millares: $mill")
        println("Cantidad de centenares: $cen")
        println("Cantidad de decenas: $dec")
        println("Cantidad de unidades: $uni")
    }else{
        println("Fuera del rango")
    }
}
 */

/*3. Hacer un programa que pida un número en decimal y nos devuelva su equivalente en
binario, octal y hexadecimal*/
/*fun main() {

    println("Ingrese un numero decimal")
    val n = readLine()!!.toInt()

    val binary: String = Integer.toBinaryString(n)

    println("Equivalente binario: $binary ")        // 1001011

    val octalResult = Integer.toOctalString(n)

    println("Equivalente Octal: $octalResult")

    val hexadecimal: String = Integer.toHexString(n)
    println("Equivalente Hexadecimal: $hexadecimal")

}
 */

/*4. Hacer un programa que pida una cadena y nos diga si es palíndromo o no*/
/*fun main(Args: Array<String>) {

    var (igual, aux) = Pair(0, 0)
    var texto: String
    print("Ingrese una frase: ")
    texto = readLine() as String
    var reverse = texto.reversed()
    if(texto == reverse) {
        println("$texto es palindromo!!")
    } else {
        println("$texto no es palindromo!!")
    }
}
 */

/*5.Hacer un programa que pida el valor de los lados de
   un triángulo y nos diga que tipo de triángulo es.*/
/*fun main(args: Array<String>) {

    println("Ingrese la medida de los lados del triagulo:")
    print("Lado 1: ")
    var lad1 = readLine()!!.toInt()
    print("Lado 2: ")
    var lad2 = readLine()!!.toInt()
    print("Lado 3: ")
    var lad3 = readLine()!!.toInt()

    if (lad1 == lad2 && lad2 == lad3) {
        println("El triángulo es equilátero")
    } else if (lad1 == lad2 && lad2 != lad3) {
        println("El triángulo es isosceles")
    } else if (lad1 == lad3 && lad3 != lad2) {
        println("El triángulo es isosceles")
    } else if (lad2 == lad3 && lad3 != lad1) {
        println("El triángulo es isosceles")
    } else {
        println("El triángulo es escaleno")
    }
}
 */

/*6.Hacer un programa que mediante funciones permita calcular
    el factorial de un número.*/
/*fun main(args: Array<String>) {
    print("Ingrese un número: ")
    var num = readLine()!!.toInt()

    for (i in num-1 downTo 1){
        num = num * i
    }
    print("El factorial es: $num")
}
 */

/*7. Hacer un programa que llene un arreglo de cadenas de caracteres y lo imprima en el orden de la cadena
* mas corta a la mas grande*/
/*fun main(args: Array<String>) {
    val palabra = arrayOf("Hola","Murcielago","Sol")

    palabra.sortBy{it.length}

    println("El orden es: ")

    for(cadena in palabra){
        println(cadena)
    }
}
 */

/*8. Hacer un programa que permita contar cuantas vocales tiene una cadena de
* caracteres. El programa debera decir cuantas vocales son el total,
* asi como cuantas hay por cada una de ellas*/
fun main(args: Array<String>) {
    println("Ingrese una palabra")
    val palabra = readln()
    val vocales="aeiouAEIOU"
    var totalv = 0
    var contarVocales = mutableMapOf<Char, Int>()

    for (caracter in palabra){
        if(caracter in vocales){
            contarVocales[caracter] = (contarVocales[caracter] ?: 0) + 1
            totalv++
        }
    }
    println("Vocales en total: $totalv ")
    for ((vocal,contador) in contarVocales){
        println("La vocal $vocal aparece $contador veces")
    }

}







